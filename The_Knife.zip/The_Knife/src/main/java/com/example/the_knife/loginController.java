package com.example.the_knife;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.File;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;


public class loginController {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private TextField userRegister;
    @FXML
    private PasswordField passRegister;
    @FXML
    private TextField nomeField;
    @FXML
    private TextField cognomeField;
    @FXML
    private ToggleGroup ruoloToggleGroup;
    @FXML
    private RadioButton rist;
    @FXML
    private RadioButton cliente;
    @FXML
    private TextField numTel;
    @FXML
    private DatePicker dataNascita;
    @FXML
    private TextField indirizzo;

    @FXML
    private void handleLogin() {
        //METODI CHE CHIAMO

        //DEFINIZIONE handleLogin
        String user = usernameField.getText();
        String pass = passwordField.getText();
        if (user.equals("admin") && pass.equals("12345")) {
            System.out.println("Login successful");
        }
        // TODO: handle login logic
    }

    @FXML
    private void handleRegister() {

        //METODI CHE CHIAMO
        handleSubmit();

        //DEFINIZIONE handleRegister
        String newUser = userRegister.getText();
        String newPass = passRegister.getText();
        String name = nomeField.getText();
        String cognome = cognomeField.getText();
        String numerotel = numTel.getText();
        String indirizzo = this.indirizzo.getText();
        LocalDate DataNascita = dataNascita.getValue();

        try {
            Utente nuovo = new Utente();

            nuovo.Username = newUser;
            nuovo.Password = newPass;
            nuovo.Nome = name;
            nuovo.Cognome = cognome;
            nuovo.Indirizzo = indirizzo;
            nuovo.DataDiNascita = DataNascita;
            nuovo.Telefono = numerotel;

            aggiungiUtente(nuovo, "fileUtenti.json");



        } catch (Exception e) {
            e.printStackTrace();
        }


        // TODO: handle registration logic
        System.out.println("Registration successful");
        System.out.println("Riepilogo:");
        System.out.println("Username: "+newUser +"\nPassword: "+newPass+"\nNome: "+name+"\nCognome:" +cognome+"\nNumero di telefono: "+numerotel+"\nData di nascita: "+DataNascita+"\nIndirizzo: "+indirizzo);
    }

    @FXML
    private void handleSubmit() {
        RadioButton selected = (RadioButton) ruoloToggleGroup.getSelectedToggle(); //casto il ruolo dal toggle group che ho definito nel file fxml
        if (selected != null) {
            System.out.println("Ruolo selezionato: " + selected.getText());
        }
    }

    // Metodo per aggiungere un nuovo utente a un file JSON esistente
    public static void aggiungiUtente(Utente nuovo, String fileJson) {
        try {

            ObjectMapper mapper = new ObjectMapper();// Crea un'istanza di ObjectMapper
            mapper.registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule());
            File file = new File(fileJson);// Crea un oggetto File per rappresentare il file JSON passato come parametro

            if (!file.exists()) {
                System.out.println("File non trovato: " + file.getAbsolutePath());
                return;
            }

            JsonNode root = mapper.readTree(file);// Legge l'intero contenuto del file come un albero JSON

            List<Utente> listaModificabile = new ArrayList<>();// Prepara una lista modificabile di Utente (vuota per ora)

            JsonNode utentiNode = root.get("Utenti"); // Recupera il nodo "Utenti" dall'albero JSON

            // Se il nodo esiste e contiene un array
            if (utentiNode != null && utentiNode.isArray()) {
                Utente[] utentiArray = mapper.treeToValue(utentiNode, Utente[].class); // Converte l'array JSON in un array Java di oggetti Utente
                listaModificabile = new ArrayList<>(Arrays.asList(utentiArray)); // Converte l'array in una lista modificabile
            }

            listaModificabile.add(nuovo); // Aggiunge il nuovo utente alla lista

            System.out.println("Utente '" + nuovo.Nome + "' registrato con successo.");

            ObjectNode nuovoRoot = mapper.createObjectNode();// Crea un nuovo oggetto JSON vuoto (root)

            nuovoRoot.set("Utenti", mapper.valueToTree(listaModificabile));// Imposta il nodo "Utenti" con la lista aggiornata di utenti convertita in JSON

            mapper.writerWithDefaultPrettyPrinter().writeValue(file, nuovoRoot);// Scrive l'albero JSON aggiornato nel file, sovrascrivendolo con formattazione leggibile

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}