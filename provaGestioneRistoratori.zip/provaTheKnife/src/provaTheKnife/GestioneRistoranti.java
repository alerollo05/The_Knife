package provaTheKnife;

import java.util.Comparator;
import java.util.Iterator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GestioneRistoranti {
	
	public static void aggiungiRistorante(Ristorante nuovo, String fileJson) {
        try {
            ObjectMapper mapper = new ObjectMapper();

            // Legge l'albero JSON
            JsonNode root = mapper.readTree(new File(fileJson));
            JsonNode ristorantiNode = root.get("ristoranti");

            // Deserializza in List<Ristorante>
            List<Ristorante> ristoranti = Arrays.asList(mapper.treeToValue(ristorantiNode, Ristorante[].class));

            // Converte in lista modificabile
            List<Ristorante> listaModificabile = new ArrayList<>(ristoranti);

            // Aggiunge il nuovo ristorante
            listaModificabile.add(nuovo);

            System.out.println("Ristorante '" + nuovo.Name + "' aggiunto con successo.");

            // Ricrea l'oggetto JSON aggiornato
            ObjectNode nuovoRoot = mapper.createObjectNode();
            nuovoRoot.set("ristoranti", mapper.valueToTree(listaModificabile));

            // Sovrascrive il file
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(fileJson), nuovoRoot);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public static void rimuoviRistorantePerNome(String nome, String fileJson) {
        try {
            ObjectMapper mapper = new ObjectMapper();

            // Legge l'albero JSON
            JsonNode root = mapper.readTree(new File(fileJson));
            JsonNode ristorantiNode = root.get("ristoranti");

            // Deserializza in List<Ristorante>
            List<Ristorante> ristoranti = Arrays.asList(mapper.treeToValue(ristorantiNode, Ristorante[].class));

            // Converte in lista modificabile
            List<Ristorante> listaModificabile = new ArrayList<>(ristoranti);

            // Rimuove per nome
            boolean rimosso = listaModificabile.removeIf(r -> r.Name.equalsIgnoreCase(nome));
            // Equivale a scrivere :
            /*boolean rimosso = false;
            Iterator<Ristorante> iterator = listaModificabile.iterator();
            while (iterator.hasNext()) {
                Ristorante r = iterator.next();
                if (r.Name.equalsIgnoreCase(nome)) {
                    iterator.remove();
                    rimosso = true;
                }
            }*/
            
            if (rimosso) {
                System.out.println("Ristorante '" + nome + "' rimosso con successo.");
            } else {
                System.out.println("Nessun ristorante trovato con il nome '" + nome + "'.");
            }

            // Ricrea l'oggetto JSON aggiornato
            ObjectNode nuovoRoot = mapper.createObjectNode();
            nuovoRoot.set("ristoranti", mapper.valueToTree(listaModificabile));

            // Sovrascrive il file
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(fileJson), nuovoRoot);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public static void visualizzaRecensioniPerNomeRistorante(String nomeRistorante, String fileJson, String criterio) {
	    try {
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode root = mapper.readTree(new File(fileJson));
	        JsonNode ristorantiNode = root.get("ristoranti");

	        List<Ristorante> ristoranti = Arrays.asList(mapper.treeToValue(ristorantiNode, Ristorante[].class));

	        Ristorante ristorante = null;
	        for (Ristorante r : ristoranti) {
	            if (r.Name.equalsIgnoreCase(nomeRistorante)) {
	                ristorante = r;
	                break;
	            }
	        }


	        if (ristorante == null) {
	            System.out.println("Ristorante '" + nomeRistorante + "' non trovato.");
	            return;
	        }

	        if (ristorante.recensioni == null || ristorante.recensioni.isEmpty()) {
	            System.out.println("Il ristorante '" + nomeRistorante + "' non ha recensioni.");
	            return;
	        }

	        List<Recensione> recensioni = new ArrayList<>(ristorante.recensioni);

	        switch (criterio.toLowerCase()) {
	            case "data":
	                recensioni.sort(Comparator.comparing((Recensione r) -> r.date).reversed());
	                break;
	            case "rating":
	                recensioni.sort(Comparator.comparingInt((Recensione r) -> r.rating).reversed());
	                break;
	            default:
	                System.out.println("Criterio non valido. Usa 'data' o 'rating'.");
	                return;
	        }

	        System.out.println("Recensioni per '" + nomeRistorante + "' ordinate per '" + criterio + "':");
	        for (Recensione rec : recensioni) {
	            System.out.println(" - [" + rec.date + "] " + rec.author + " (" + rec.rating + "): " + rec.comment);
	            if (rec.risposta != null && !rec.risposta.isEmpty()) {
	                System.out.println("   Risposta: " + rec.risposta);
	            }
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public static void visualizzaRiepilogoRistorante(String nomeRistorante, String fileJson) {
	    try {
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode root = mapper.readTree(new File(fileJson));
	        JsonNode ristorantiNode = root.get("ristoranti");

	        List<Ristorante> ristoranti = Arrays.asList(mapper.treeToValue(ristorantiNode, Ristorante[].class));
	        List<Ristorante> listaModificabile = new ArrayList<>(ristoranti);

	        boolean trovato = false;

	        for (Ristorante r : listaModificabile) {
	            if (r.Name.equalsIgnoreCase(nomeRistorante)) {

	                // Aggiorna MediaRec
	            	double mediaRecensioni = aggiornaMediaRecensioni(nomeRistorante,fileJson);

	                // Visualizza riepilogo
	                System.out.println("----- Riepilogo Ristorante -----");
	                System.out.println("Nome: " + r.Name);
	                System.out.println("Indirizzo: " + r.Address);
	                System.out.println("Cucina: " + r.Cuisine);
	                System.out.println("Numero Recensioni: " + r.NumRec);
	                System.out.println("Media Recensioni: " + r.MediaRec);
	                System.out.println("Consegna a domicilio: " + (r.Delivery ? "Sì" : "No"));
	                System.out.println("-------------------------------");

	                trovato = true;
	                break;
	            }
	        }

	        if (!trovato) {
	            System.out.println("Ristorante '" + nomeRistorante + "' non trovato.");
	        } else {
	            // Sovrascrive il file JSON con i dati aggiornati
	            ObjectNode nuovoRoot = mapper.createObjectNode();
	            nuovoRoot.set("ristoranti", mapper.valueToTree(listaModificabile));
	            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(fileJson), nuovoRoot);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	
	public static void rispondiAllaRecensione(String nomeRistorante, String autoreRecensione, String risposta, String fileJson) {
	    try {
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode root = mapper.readTree(new File(fileJson));
	        JsonNode ristorantiNode = root.get("ristoranti");

	        List<Ristorante> ristoranti = Arrays.asList(mapper.treeToValue(ristorantiNode, Ristorante[].class));
	        List<Ristorante> listaModificabile = new ArrayList<>(ristoranti);

	        boolean trovatoRistorante = false;
	        boolean trovatoRecensione = false;

	        for (Ristorante r : listaModificabile) {
	            if (r.Name.equalsIgnoreCase(nomeRistorante)) {
	                trovatoRistorante = true;
	                if (r.recensioni != null) {
	                    for (Recensione rec : r.recensioni) {
	                        if (rec.author.equalsIgnoreCase(autoreRecensione)) {
	                            rec.risposta = risposta;
	                            trovatoRecensione = true;
	                            System.out.println("Risposta aggiornata per la recensione di '" + autoreRecensione + "'.");
	                            break;
	                        }
	                    }
	                }
	                break;
	            }
	        }

	        if (!trovatoRistorante) {
	            System.out.println("Ristorante '" + nomeRistorante + "' non trovato.");
	        } else if (!trovatoRecensione) {
	            System.out.println("Recensione di '" + autoreRecensione + "' non trovata.");
	        }

	        // Ricrea l'oggetto JSON aggiornato
	        ObjectNode nuovoRoot = mapper.createObjectNode();
	        nuovoRoot.set("ristoranti", mapper.valueToTree(listaModificabile));

	        // Sovrascrive il file
	        mapper.writerWithDefaultPrettyPrinter().writeValue(new File(fileJson), nuovoRoot);

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public static double aggiornaMediaRecensioni(String nomeRistorante, String fileJson) {
	    try {
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode root = mapper.readTree(new File(fileJson));
	        JsonNode ristorantiNode = root.get("ristoranti");

	        List<Ristorante> ristoranti = Arrays.asList(mapper.treeToValue(ristorantiNode, Ristorante[].class));
	        List<Ristorante> listaModificabile = new ArrayList<>(ristoranti);

	        for (Ristorante r : listaModificabile) {
	            if (r.Name.equalsIgnoreCase(nomeRistorante)) {
	                if (r.recensioni != null && !r.recensioni.isEmpty()) {
	                    double somma = 0;
	                    for (Recensione rec : r.recensioni) {
	                        somma += rec.rating;
	                    }
	                    double media = somma / r.recensioni.size();
	                    media = Math.round(media * 100.0) / 100.0;
	                    r.MediaRec = media;
	                } else {
	                    r.MediaRec = 0;
	                }

	                ObjectNode nuovoRoot = mapper.createObjectNode();
	                nuovoRoot.set("ristoranti", mapper.valueToTree(listaModificabile));
	                mapper.writerWithDefaultPrettyPrinter().writeValue(new File(fileJson), nuovoRoot);

	                return r.MediaRec;
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return -1; // Se ristorante non trovato o errore
	}

	



}
