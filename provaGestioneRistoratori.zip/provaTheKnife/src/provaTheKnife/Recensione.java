package provaTheKnife;

public class Recensione {
	public String author;
    public int rating;
    public String comment;
    public String date;
    public String risposta;

}
