package com.example.the_knife.Ristoratore;

import com.example.the_knife.Utente.ListaUtenti;
import com.example.the_knife.Utente.SessionManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.io.File;
import java.io.IOException;

public class RistorantiRistController extends dashBoardRistController {

    @FXML
    private Label welcomeLabel;
   /* @FXML
    private TableView<Ristorante> tableView;
    @FXML
    private TableColumn<Ristorante, String> colNome;
    @FXML
    private TableColumn<Ristorante, String> colIndirizzo;
    @FXML
    private TableColumn<Ristorante, Double> colRating;
    */
    SessionManager session = SessionManager.getInstance();
    private final String user = session.getUsername();
    private final int id = session.getUserId();
    private final String ruolo = session.getRuolo();



    public void initialize() {
        welcomeLabel.setText("I TUOI RISTORANTI " + user + "");
        System.out.println("Utente: "+user+ " Id: "+id+" Ruolo: "+ruolo);
        try {
            ObjectMapper mapper = new ObjectMapper(); // Crea un oggetto ObjectMapper di Jackson per la deserializzazione JSON
            mapper.registerModule(new JavaTimeModule()); // Registra un modulo per la gestione corretta di LocalDate e altri tipi Java Time
            ListaUtenti lista = mapper.readValue(new File("fileUtenti.json"), ListaUtenti.class); // Deserializza il file JSON in un oggetto ListaUtenti
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onRistorantiClick(ActionEvent event) throws IOException {
        onRistorantiClick(event);
    }
    @FXML
    public void onAddRistClick(ActionEvent event) throws IOException {
        super.onAddRistClick(event);
    }
    @FXML
    public void handleLogOut(ActionEvent event) {
        super.handleLogOut(event);
    }

    @Override
    public void closeProgram(ActionEvent event) {
        super.closeProgram(event);
    }

    @FXML
    protected void goBack(ActionEvent event) throws IOException {
        super.goBack(event);
    }
    @FXML
    protected void onProfileClick(ActionEvent event) throws IOException {
        super.onProfileClick(event);
    }
}
