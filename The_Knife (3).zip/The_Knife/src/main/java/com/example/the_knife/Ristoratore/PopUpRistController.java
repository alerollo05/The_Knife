package com.example.the_knife.Ristoratore;

import com.example.the_knife.Utente.SessionManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PopUpRistController {

    @FXML
    private Label label1;

    @FXML
    private Button okButton;

    @FXML
    private TextField txt1;

    public void handleClose(ActionEvent event) {
        // Chiude la finestra corrente
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.close();
        //Al massimo posso aggiornare la pagina rifacendo di nuovo goTo per leggere il dato nuovo
    }
    public void initialize(){
            switch(SessionManager.idScelta){
                case 1:
                    label1.setText("Cambia nome:");
                    txt1.setPromptText("Inserisci il nuovo nome");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newNome = txt1.getText();
                        System.out.println(newNome);
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 2:
                    label1.setText("Cambia indirizzo:");
                    txt1.setPromptText("Inserisci il nuovo indirizzo");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newAddr = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 3:
                    label1.setText("Cambia Città:");
                    txt1.setPromptText("Inserisci la nuova città");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newCit = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 4:
                    label1.setText("Cambia Cucina:");
                    txt1.setPromptText("Inserisci il nuovo tipo di cucina");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newCuc = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 5:
                    label1.setText("Cambia Telefono:");
                    txt1.setPromptText("+39 0123456789");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newTel = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 6:
                    label1.setText("Cambia Email:");
                    txt1.setPromptText("Inserisci la nuova mail");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newMail = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 7:
                    label1.setText("Cambia URL:");
                    txt1.setPromptText("Inserisci il nuovo URL");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newUrl = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 8:
                    label1.setText("Cambia Descrizione:");
                    txt1.setPromptText("Inserisci la nuova descrizione");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newDesc = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 9:
                    label1.setText("Cambia Prezzo:");
                    txt1.setPromptText("Inserisci il nuovo prezzo medio");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newPrice = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 10:
                    label1.setText("Cambia Stelle:");
                    txt1.setPromptText("Inserisci il numero di stelle");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newStar = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;
                case 11:
                    label1.setText("Cambia Servizi:");
                    txt1.setPromptText("Cambia i tuoi servizi");
                    okButton.setText("Conferma");
                    okButton.setOnAction(e -> {
                        String newServ = txt1.getText();
                        handleClose(e);//chiudi finestra popUp
                    });
                    break;

            }
    }
}
