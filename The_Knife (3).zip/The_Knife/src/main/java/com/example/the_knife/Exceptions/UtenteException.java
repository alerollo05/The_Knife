package com.example.the_knife.Exceptions;

public class UtenteException extends RuntimeException {
    public UtenteException(String message) {
        super(message);
    }
}
