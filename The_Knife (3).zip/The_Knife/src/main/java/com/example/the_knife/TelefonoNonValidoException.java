package com.example.the_knife;

public class TelefonoNonValidoException extends RuntimeException {
    public TelefonoNonValidoException(String message) {
        super(message);
    }
}
