package com.example.the_knife;

public class UtenteException extends RuntimeException {
    public UtenteException(String message) {
        super(message);
    }
}
