package com.example.the_knife.Exceptions;

public class TelefonoNonValidoException extends RuntimeException {
    public TelefonoNonValidoException(String message) {
        super(message);
    }
}
