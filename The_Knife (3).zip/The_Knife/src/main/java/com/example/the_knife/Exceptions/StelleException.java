package com.example.the_knife.Exceptions;

public class StelleException extends RuntimeException {
    public StelleException(String message) {
        super(message);
    }
}
