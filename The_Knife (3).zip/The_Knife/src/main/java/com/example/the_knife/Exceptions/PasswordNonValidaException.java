package com.example.the_knife.Exceptions;

public class PasswordNonValidaException extends RuntimeException {
    public PasswordNonValidaException(String message) {
        super(message);
    }
}
