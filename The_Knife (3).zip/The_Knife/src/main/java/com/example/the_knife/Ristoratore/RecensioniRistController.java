package com.example.the_knife.Ristoratore;

import com.example.the_knife.Utente.SessionManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.io.IOException;

public class RecensioniRistController extends RistorantiRistController {

    @FXML
    private Label welcomeLabel;

    SessionManager session = SessionManager.getInstance();
    private final String user = session.getUsername();
    private final int id = session.getUserId();
    private final String ruolo = session.getRuolo();
    /*
    Label recensioniLabel = new Label("Recensioni: ");
            recensioniLabel.getStyleClass().add("textNormal");

    Label numRecLabel = new Label("Numero di recensioni: ");
            numRecLabel.getStyleClass().add("textNormal");

    Label mediaRecLabel = new Label("Media recensioni: ");
            mediaRecLabel.getStyleClass().add("textNormal");

    Label numRec = new Label("Numero di recensioni: ");
            numRec.getStyleClass().add("textNormal"); */

    public void initialize() {
        welcomeLabel.setText("LE RECENSIONI AL TUO RISTORANTE " + user);
        System.out.println("Utente: " + user + " Id: " + id + " Ruolo: " + ruolo);
    }


    @FXML
    protected void goBack(ActionEvent event) throws IOException {
        SessionManager.idRist = null;
        super.goTo(event, "ristorantiRist.fxml");
    }

    public void handleLogOut(ActionEvent event) {
        SessionManager.idRist = null;
        super.handleLogOut(event);
    }

    @Override
    public void closeProgram(ActionEvent event) {
        super.closeProgram(event);
    }
}
