package com.example.the_knife.Exceptions;

public class NumMaxCaratteriException extends RuntimeException {
    public NumMaxCaratteriException(String message) {
        super(message);
    }
}
