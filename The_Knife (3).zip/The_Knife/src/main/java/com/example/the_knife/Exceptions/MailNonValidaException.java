package com.example.the_knife.Exceptions;

public class MailNonValidaException extends RuntimeException {
    public MailNonValidaException(String message) {
        super(message);
    }
}
