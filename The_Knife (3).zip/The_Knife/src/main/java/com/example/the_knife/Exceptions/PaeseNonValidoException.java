package com.example.the_knife.Exceptions;

public class PaeseNonValidoException extends RuntimeException {
    public PaeseNonValidoException(String message) {
        super(message);
    }
}
