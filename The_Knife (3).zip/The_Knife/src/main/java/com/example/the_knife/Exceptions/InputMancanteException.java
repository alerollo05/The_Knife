package com.example.the_knife.Exceptions;

public class InputMancanteException extends RuntimeException {
    public InputMancanteException(String message) {
        super(message);
    }
}
